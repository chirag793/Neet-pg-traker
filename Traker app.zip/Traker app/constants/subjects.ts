{\rtf1\ansi\ansicpg1252\cocoartf2865
\cocoatextscaling1\cocoaplatform1{\fonttbl\f0\fmodern\fcharset0 Courier;\f1\fnil\fcharset0 Menlo-Regular;}
{\colortbl;\red255\green255\blue255;\red250\green250\blue250;\red197\green134\blue192;\red212\green212\blue212;
\red156\green220\blue254;\red206\green145\blue120;\red86\green156\blue214;\red106\green153\blue85;\red78\green201\blue176;
\red181\green206\blue168;}
{\*\expandedcolortbl;;\cssrgb\c98039\c98039\c98039;\cssrgb\c77255\c52549\c75294;\cssrgb\c83137\c83137\c83137;
\cssrgb\c61176\c86275\c99608;\cssrgb\c80784\c56863\c47059;\cssrgb\c33725\c61176\c83922;\cssrgb\c41569\c60000\c33333;\cssrgb\c30588\c78824\c69020;
\cssrgb\c70980\c80784\c65882;}
\deftab720
\pard\pardeftab720\qr\partightenfactor0

\f0\fs24 \cf2 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec2 2\
3\
4\
5\
6\
7\
8\
9\
10\
11\
12\
13\
14\
15\
16\
17\
18\
19\
20\
21\
22\
23\
24\
25\
26\
27\
28\
29\
30\
31\
32\
33\
34\
35\
36\
37\
38\
39\
40\
41\
42\
43\
44\
45\
46\
47\
48\
49\
50\
51\
52\
53\
54\
55\
56\
57\
58\
59\
60\
61\
62\
63\
64\
65\
66\
67\
68\
69\
70\
\pard\pardeftab720\partightenfactor0

\f1 \cf3 \strokec3 import\cf2 \strokec2  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 Subject\cf2 \strokec2  \cf4 \strokec4 \}\cf2 \strokec2  \cf3 \strokec3 from\cf2 \strokec2  \cf6 \strokec6 '@/types/study'\cf4 \strokec4 ;\cf2 \strokec2 \
\
\cf3 \strokec3 export\cf2 \strokec2  \cf7 \strokec7 const\cf2 \strokec2  \cf5 \strokec5 MEDICAL_SUBJECTS\cf2 \strokec2  \cf4 \strokec4 =\cf2 \strokec2  \cf4 \strokec4 [\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'anatomy'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Anatomy'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#FF6B6B'\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'physiology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Physiology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#4ECDC4'\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'biochemistry'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Biochemistry'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#45B7D1'\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'pathology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Pathology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#96CEB4'\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'pharmacology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Pharmacology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#FFEAA7'\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'microbiology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Microbiology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#DDA0DD'\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'forensic'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Forensic Medicine'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#98D8C8'\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'community'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Community Medicine'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#F7DC6F'\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'medicine'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Medicine'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#85C1E2'\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'surgery'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Surgery'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#F8B739'\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'obgyn'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'OB/GYN'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#E8DAEF'\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'pediatrics'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Pediatrics'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#ABEBC6'\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'ophthalmology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Ophthalmology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#FAD7A0'\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'ent'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'ENT'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#D5A6BD'\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'orthopedics'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Orthopedics'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#AED6F1'\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'radiology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Radiology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#A9DFBF'\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'psychiatry'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Psychiatry'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#F9E79F'\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'dermatology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Dermatology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#D2B4DE'\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'anesthesia'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Anesthesia'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#A3E4D7'\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf4 \strokec4 ];\cf2 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf8 \strokec8 // Default subjects with target hours for initialization\cf2 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf3 \strokec3 export\cf2 \strokec2  \cf7 \strokec7 const\cf2 \strokec2  \cf5 \strokec5 DEFAULT_SUBJECTS\cf4 \strokec4 :\cf2 \strokec2  \cf9 \strokec9 Subject\cf4 \strokec4 []\cf2 \strokec2  \cf4 \strokec4 =\cf2 \strokec2  \cf4 \strokec4 [\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'anatomy'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Anatomy'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#FF6B6B'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 targetHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 150\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 completedHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 0\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'physiology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Physiology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#4ECDC4'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 targetHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 120\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 completedHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 0\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'biochemistry'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Biochemistry'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#45B7D1'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 targetHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 100\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 completedHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 0\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'pathology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Pathology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#96CEB4'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 targetHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 130\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 completedHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 0\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'pharmacology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Pharmacology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#FFEAA7'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 targetHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 110\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 completedHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 0\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'microbiology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Microbiology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#DDA0DD'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 targetHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 90\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 completedHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 0\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'forensic'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Forensic Medicine'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#98D8C8'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 targetHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 80\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 completedHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 0\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'community'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Community Medicine'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#F7DC6F'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 targetHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 85\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 completedHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 0\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'medicine'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Medicine'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#85C1E2'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 targetHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 200\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 completedHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 0\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'surgery'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Surgery'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#F8B739'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 targetHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 180\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 completedHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 0\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'obgyn'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'OB/GYN'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#E8DAEF'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 targetHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 120\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 completedHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 0\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'pediatrics'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Pediatrics'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#ABEBC6'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 targetHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 140\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 completedHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 0\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'ophthalmology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Ophthalmology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#FAD7A0'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 targetHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 70\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 completedHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 0\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'ent'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'ENT'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#D5A6BD'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 targetHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 70\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 completedHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 0\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'orthopedics'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Orthopedics'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#AED6F1'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 targetHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 90\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 completedHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 0\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'radiology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Radiology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#A9DFBF'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 targetHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 80\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 completedHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 0\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'psychiatry'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Psychiatry'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#F9E79F'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 targetHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 75\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 completedHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 0\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'dermatology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Dermatology'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#D2B4DE'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 targetHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 65\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 completedHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 0\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf4 \strokec4 \{\cf2 \strokec2  \cf5 \strokec5 id\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'anesthesia'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Anesthesia'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 color\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '#A3E4D7'\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 targetHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 70\cf4 \strokec4 ,\cf2 \strokec2  \cf5 \strokec5 completedHours\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 0\cf2 \strokec2  \cf4 \strokec4 \},\cf2 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf4 \strokec4 ];\cf2 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf8 \strokec8 // Default exam dates - INICET is usually in May (2nd Sunday)\cf2 \strokec2 \
\cf8 \strokec8 // NEET PG dates vary each year\cf2 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf3 \strokec3 export\cf2 \strokec2  \cf7 \strokec7 const\cf2 \strokec2  \cf5 \strokec5 DEFAULT_EXAM_DATES\cf2 \strokec2  \cf4 \strokec4 =\cf2 \strokec2  \cf4 \strokec4 \{\cf2 \strokec2 \
  \cf5 \strokec5 NEET_PG\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '2025-07-07'\cf4 \strokec4 ,\cf2 \strokec2  \cf8 \strokec8 // Usually in June/July\cf2 \strokec2 \
  \cf5 \strokec5 INICET\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 '2025-05-11'\cf4 \strokec4 ,\cf2 \strokec2  \cf8 \strokec8 // Usually 2nd Sunday of May\cf2 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf4 \strokec4 \};\cf2 \strokec2 \
\
\pard\pardeftab720\partightenfactor0
\cf3 \strokec3 export\cf2 \strokec2  \cf7 \strokec7 const\cf2 \strokec2  \cf5 \strokec5 EXAM_INFO\cf2 \strokec2  \cf4 \strokec4 =\cf2 \strokec2  \cf4 \strokec4 \{\cf2 \strokec2 \
  \cf5 \strokec5 INICET\cf4 \strokec4 :\cf2 \strokec2  \cf4 \strokec4 \{\cf2 \strokec2 \
    \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'INICET'\cf4 \strokec4 ,\cf2 \strokec2 \
    \cf5 \strokec5 fullName\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Institute of National Importance Combined Entrance Test'\cf4 \strokec4 ,\cf2 \strokec2 \
    \cf5 \strokec5 description\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Usually held on 2nd Sunday of May'\cf4 \strokec4 ,\cf2 \strokec2 \
    \cf5 \strokec5 defaultMonth\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 5\cf4 \strokec4 ,\cf2 \strokec2  \cf8 \strokec8 // May\cf2 \strokec2 \
    \cf5 \strokec5 defaultDay\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 11\cf4 \strokec4 ,\cf2 \strokec2  \cf8 \strokec8 // 2nd Sunday (approximate)\cf2 \strokec2 \
  \cf4 \strokec4 \},\cf2 \strokec2 \
  \cf5 \strokec5 NEET_PG\cf4 \strokec4 :\cf2 \strokec2  \cf4 \strokec4 \{\cf2 \strokec2 \
    \cf5 \strokec5 name\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'NEET PG'\cf4 \strokec4 ,\cf2 \strokec2 \
    \cf5 \strokec5 fullName\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'National Eligibility cum Entrance Test - Postgraduate'\cf4 \strokec4 ,\cf2 \strokec2 \
    \cf5 \strokec5 description\cf4 \strokec4 :\cf2 \strokec2  \cf6 \strokec6 'Date varies each year (usually June-July)'\cf4 \strokec4 ,\cf2 \strokec2 \
    \cf5 \strokec5 defaultMonth\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 7\cf4 \strokec4 ,\cf2 \strokec2  \cf8 \strokec8 // July\cf2 \strokec2 \
    \cf5 \strokec5 defaultDay\cf4 \strokec4 :\cf2 \strokec2  \cf10 \strokec10 7\cf4 \strokec4 ,\cf2 \strokec2 \
  \cf4 \strokec4 \},\cf2 \strokec2 \
\pard\pardeftab720\partightenfactor0
\cf4 \strokec4 \};\cf2 \strokec2 \
}